﻿namespace Algorithms
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void PathFinderDebugHandler(int fromX, int fromY, int x, int y, PathFinderNodeType type, int totalCost, int cost);
}

