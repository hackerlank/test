﻿namespace Net
{
    using System;

    public enum USocketType
    {
        Fir,
        GateWay
    }
}

