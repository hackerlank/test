﻿namespace Net
{
    using System;

    public class GlobalVar
    {
        public const int MAX_ACCNAMESIZE = 0x30;
        public const int MAX_CHATINFO = 0x100;
        public const int MAX_FLAT_LENGTH = 100;
        public const int MAX_GATEWAYUSER = 0xfa0;
        public const int MAX_IP_LENGTH = 0x10;
        public const int MAX_IPHONE_UUID = 40;
        public const int MAX_MAC_ADDR = 0x18;
        public const int MAX_NAMESIZE = 0x20;
        public const int MAX_PASSWORD = 0x10;
    }
}

