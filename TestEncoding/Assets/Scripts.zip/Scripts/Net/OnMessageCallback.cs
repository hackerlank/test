﻿namespace Net
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void OnMessageCallback(UMessage message);
}

