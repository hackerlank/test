﻿using System;

public enum LoadSceneState
{
    NotLoading,
    Loading,
    LoadingFinish
}

