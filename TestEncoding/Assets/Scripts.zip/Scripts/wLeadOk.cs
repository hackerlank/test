﻿namespace MGUI
{
    using System;

    public enum wLeadOk
    {
        ArenaAndSecret = 6,
        ArenaTeam = 2,
        SecretTeam = 3,
        Team = 1,
        TeamAndArena = 4,
        TeamAndArenaAndSecret = 7,
        TeamAndSecret = 5
    }
}

