﻿using System;

public enum UserState
{
    USTATE_NOSTATE,
    USTATE_HIDE,
    USTATE_DEATH,
    USTATE_SHENPAN,
    USTATE_ZHI_MING_DA_JI,
    USTATE_SILENT,
    USTATE_MAX
}

