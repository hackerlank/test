﻿using System;

public enum MoveDirction
{
    USER_DIR_UP,
    USER_DIR_UPRIGHT,
    USER_DIR_RIGHT,
    USER_DIR_RIGHTDOWN,
    USER_DIR_DOWN,
    USER_DIR_DOWNLEFT,
    USER_DIR_LEFT,
    USER_DIR_LEFTUP,
    USER_DIR_WRONG
}

