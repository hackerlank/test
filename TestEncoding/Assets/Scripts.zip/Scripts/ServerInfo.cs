﻿using System;

public class ServerInfo
{
    public int id;
    public string ip;
    public string name;
    public string port;
}

