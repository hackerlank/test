﻿namespace Graphics
{
    using System;

    public class GraphConst
    {
        public const int invalid_node_index = -1;
    }
}

