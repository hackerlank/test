﻿using System;

public class MsgVar
{
    public const byte ALL_CHAT_USERCMD_PARAMETER = 1;
    public const byte CHAT_USERCMD = 14;
    public const byte NULL_USERCMD_PARA = 0;
}

