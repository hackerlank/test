﻿using System;

public enum USAGE
{
    eSend,
    eRecv
}

