﻿using System;

public class LoginModel
{
    public string account;
    public string gateWayIp;
    public ushort gateWayPort;
    public uint gatewayTempId;
    public uint gatewayUserId;
    public byte[] key;
}

