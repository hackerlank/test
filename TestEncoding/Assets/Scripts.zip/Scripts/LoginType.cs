﻿using System;

public enum LoginType
{
    UUID,
    PlATFORM,
    NONE
}

