﻿using System;

public class stSelectUserCmd : stNullUserCmd
{
    public stSelectUserCmd()
    {
        base.byCmd = 0x18;
    }
}

