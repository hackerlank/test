﻿using System;

public class MapData
{
    public string FileName;
    public int MapID;
    public string MapName;
}

